
export default function Home() {
  return (
    <main style={{
      textAlign: 'center',
      padding: '40px',
      fontFamily: 'Arial'
    }}>
      <img src="https://via.placeholder.com/100" alt="Logo" style={{ borderRadius: '50%' }} />
      <h1>Welcome to MultiBasti</h1>
      <p>Connect with us everywhere!</p>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', marginTop: '20px' }}>
        <a href="https://youtube.com/@yourchannel" target="_blank" style={linkStyle}>🎥 YouTube</a>
        <a href="https://whatsapp.com/channel/0029VbAwEkp1NCrcSz6QRD3E" target="_blank" style={linkStyle}>💬 WhatsApp</a>
        <a href="https://facebook.com/yourpage" target="_blank" style={linkStyle}>📘 Facebook</a>
        <a href="tel:+919451142035" style={linkStyle}>📞 Call: 9451142035</a>
        <a href="mailto:manojmishra9388@gmail.com" style={linkStyle}>📧 Email Us</a>
      </div>
    </main>
  );
}

const linkStyle = {
  backgroundColor: '#000',
  color: '#fff',
  padding: '12px 18px',
  borderRadius: '8px',
  textDecoration: 'none',
  fontWeight: 'bold'
};
